#ifndef PROCESSOR_EMULATOR_PROCESSOR_H
#define PROCESSOR_EMULATOR_PROCESSOR_H

#include "../memory/memory.h"

int processor_main(Stack *ptrProgram, u_int32_t bytesForVar);

#endif
